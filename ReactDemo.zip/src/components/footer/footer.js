import React, { Component, PropTypes } from 'react';


export default React.createClass({
  render() {
    return (
      <div>
         <h2>底部footer</h2>
      </div>
    )
  }
})