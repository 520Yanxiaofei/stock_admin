/*本地调试*/
const GUARD_URL = 'http://192.168.8.252:8080/guardL3';
/*上线发布*/
// const GUARD_URL = 'api';
export default GUARD_URL