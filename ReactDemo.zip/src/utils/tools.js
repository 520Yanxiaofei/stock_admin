const randomStr = (num) => {
  return Math.random().toString(36).substr(6);
}

export {randomStr};
