import Index from './view/Index';
import Index1 from './view/Index1/';
import Index2 from './view/Index2/';
import LoginPage from './view/login/login';

const Routes = {
  index: Index,
  login: LoginPage
};

const ChildRoutes = {
  index1: Index1,
  index2: Index2
};

const RouteKeys = () => {
  let p = [];
  for (let k in Routes) {
    p.push(k);
  }
  return p;
};

const ChildRouteKeys = () => {
  let p = [];
  for (let k in ChildRoutes) {
    p.push(k);
  }
  return p;
};

export {Routes, RouteKeys, ChildRoutes, ChildRouteKeys};
